#include "MovieRating.h"



MovieRating::MovieRating(int movieID, double rating)
{
	this->movieID = movieID;
	this->rating = rating;
}


MovieRating::~MovieRating()
{
}
