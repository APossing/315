#pragma once
class MovieRating
{
public:
	int movieID;
	double rating;
	MovieRating(int movieID, double rating);
	~MovieRating();
};

