#pragma once
class CUDABackground
{
public:
	CUDABackground();
	~CUDABackground();
	int calculateCores();
};

