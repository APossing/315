#include "CUDABackground.h"



CUDABackground::CUDABackground()
{
}


CUDABackground::~CUDABackground()
{
}

int CUDABackground::calculateCores()
{
	return 2560;
}
